
import os, sys
import time
import random
import asyncio
from playwright.async_api import async_playwright


b_set  = {
	"junghhpic2": {"urls": [
									"https://studio.firebase.google.com/hhhpic2-111-76220638",
									"https://studio.firebase.google.com/hhhpic2-1112-33745257",
									"https://studio.firebase.google.com/hhhpic2-1113-42795382",
									"https://studio.firebase.google.com/hhhpic2-1114-13254674",
									"https://studio.firebase.google.com/hhhpic2-1115-64519431",
									"https://studio.firebase.google.com/hhhpic2-1116-94387210",
									"https://studio.firebase.google.com/hhhpic2-1117-61091131",
									"https://studio.firebase.google.com/hhhpic2-1118-93126526",
									"https://studio.firebase.google.com/hhhpic2-1119-17464200",
									"https://studio.firebase.google.com/hhhpic2-11110-53969206"]
	},
	"junghhpic3": {"urls": [
									"https://studio.firebase.google.com/hhhpic3-111-44880555",
									"https://studio.firebase.google.com/hhhpic3-1112-90223232",
									"https://studio.firebase.google.com/hhhpic3-111-47125770",
									"https://studio.firebase.google.com/hhhpic3-1114-17967166",
									"https://studio.firebase.google.com/hhhpic3-1115-06570620",
									"https://studio.firebase.google.com/hhhpic3-1116-60838201",
									"https://studio.firebase.google.com/hhhpic3-1116-51729262",
									"https://studio.firebase.google.com/hhhpic3-1118-90887253",
									"https://studio.firebase.google.com/hhhpic3-1119-00274019",
									"https://studio.firebase.google.com/hhhpic3-11110-77081030"]
	},
	# "junghhpic4": {"urls": [
	# 								"https://studio.firebase.google.com/hhhpic3-111-44880555",
	# 								"https://studio.firebase.google.com/hhhpic3-1112-90223232",
	# 								"https://studio.firebase.google.com/hhhpic3-111-47125770",
	# 								"https://studio.firebase.google.com/hhhpic3-1114-17967166",
	# 								"https://studio.firebase.google.com/hhhpic3-1115-06570620",
	# 								"https://studio.firebase.google.com/hhhpic3-1116-60838201",]
	# },
	"junghhpic5": {"urls": [
									"https://studio.firebase.google.com/hhhpic5-111-43439138",
									"https://studio.firebase.google.com/hhhpic5-1112-86040967",
									"https://studio.firebase.google.com/hhhpic5-1113-15733852",
									"https://studio.firebase.google.com/hhhpic5-1114-35808283",
									"https://studio.firebase.google.com/hhhpic5-1115-17580775",
									"https://studio.firebase.google.com/hhhpic5-1116-30201106",
									"https://studio.firebase.google.com/hhhpic5-1117-31981436",
									"https://studio.firebase.google.com/hhhpic5-1118-97420722",
									"https://studio.firebase.google.com/hhhpic5-1119-74840801",
									"https://studio.firebase.google.com/hhhpic5-11110-58115934"]
	},
	"junghhmarkov": {"urls": [
									"https://studio.firebase.google.com/hhhmarkov-111-36787543",
									"https://studio.firebase.google.com/hhhmarkov-1112-18747237",
									"https://studio.firebase.google.com/hhhmarkov-1113-25204068",
									"https://studio.firebase.google.com/hhhmarkov-1114-92989175",
									"https://studio.firebase.google.com/hhhmarkov-1115-40036187",
									"https://studio.firebase.google.com/hhhmarkov-1116-91261869",
									"https://studio.firebase.google.com/hhhmarkov-1117-82015368",
									"https://studio.firebase.google.com/hhhmarkov-1118-50793494",
									"https://studio.firebase.google.com/hhhmarkov-1119-33178888",
									"https://studio.firebase.google.com/hhhmarkov-11110-60275656"]
	},
}

pages = []
async def reuse_google_login():
	async with async_playwright() as p:
		browser = await p.chromium.launch(headless=False, 
																		args=["--disable-blink-features=AutomationControlled"],
																		proxy={
																						"server": "http://168.107.19.251:8080",
																						"username": "security",
																						"password": "security"
																				})
		name = random.choice(list(b_set.keys()))
		context = await browser.new_context(storage_state=f"{name}.json")
		urls = b_set[name]['urls']
		print(f"{name} : {len(urls)}")
		for url in urls:
			try:
				page = await context.new_page()
				pages.append(page)
				await page.goto(url)
				title = await page.title()				
				print(title)              # 🧠 Print the page title
				if title.startswith("Sign") or title.startswith("로그인"):
					await page.keyboard.press("Tab")
					await page.keyboard.press("Enter")
					await asyncio.sleep(5)
					title = await page.title()
					if title.startswith("Hi") or title.startswith("Welcome"):
						password = "wjdakfh2" if name == "junghhpic" else "!Wjdakfh2"
						await page.keyboard.type(password)
						await page.keyboard.press("Enter")
						await asyncio.sleep(5)
			except:
				print(f"error {url}")
		await asyncio.sleep(10)
		end_time = time.time()+3000
		while end_time > time.time():
			title = "Unknown"
			try:
				for page in pages:
					await page.bring_to_front()
					title = await page.title()
					print(title)
					await page.focus("body")
					await asyncio.sleep(2)
					modifiers = ['Control', 'Shift', 'Alt']
					mod_key = random.choice(modifiers)
					await page.keyboard.down(mod_key)
					viewport = page.viewport_size
					width = viewport['width']
					height = viewport['height']
					x = random.randint(0, width)
					y = random.randint(0, height)
					await page.mouse.move(x, y)
					await page.mouse.click(x, y)
			except:
				print(f"error : {title}")
			await asyncio.sleep(random.randint(10, 30))
		
		await context.storage_state(path=f"{name}.json")
		print(f"Session saved to {name}.json")
		for page in browser.contexts[0].pages:
			await page.close()
		await context.close()
		await browser.close()

if __name__ == "__main__":
	time.sleep(random.randint(5, 30))
	try:
		asyncio.run(reuse_google_login())
	except Exception as e:
		print(f"Error Exit : {e}")
