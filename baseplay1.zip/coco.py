# from playwright.sync_api import sync_playwright

# TOKEN="2SvPIxo3cCgho0c26131c90c50e639613ef0aea7c62b9e4b8"
# with sync_playwright() as p:
# 	browser = p.chromium.connect_over_cdp(f"wss://production-sfo.browserless.io?token={TOKEN}")

# 	context = browser.new_context(
# 		user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
# 		viewport={"width": 1280, "height": 800},
# 		locale="ko-KR",
# 		timezone_id="Asia/Seoul"
# 	)

# 📦 Install Playwright for Python
# bash
# pip install playwright
# playwright install

# 🧩 Install System Dependencies
# Playwright browsers need several shared libraries. Run:
# bash
# sudo apt-get update
# sudo apt-get install -y \
#   libnss3 \
#   libatk-bridge2.0-0 \
#   libdrm2 \
#   libxkbcommon0 \
#   libxcomposite1 \
#   libxdamage1 \
#   libxrandr2 \
#   libgbm1 \
#   libxss1 \
#   libasound2 \
#   libgtk-3-0

# 🖥️ Set Up Framebuffer with Xvfb
# To simulate a display:
# bash
# sudo apt-get install xvfb
# Xvfb :99 -screen 0 1280x1024x16 &
# DISPLAY=:99 python3 coco.py

import os
import time
import asyncio
from playwright.async_api import async_playwright
import random
import datetime
import subprocess
import traceback

urls = ["https://colab.research.google.com/github/junghh21/LLaMA-Factory/blob/main/examples/%EB%AF%B8%EB%8B%88_%ED%94%84%EB%A1%9C%EC%A0%9D%ED%8A%B8_11.ipynb",
				"https://colab.research.google.com/github/junghh21/LLaMA-Factory/blob/main/examples/%EB%AF%B8%EB%8B%88_%ED%94%84%EB%A1%9C%EC%A0%9D%ED%8A%B8_22.ipynb",
				"https://colab.research.google.com/github/junghh21/LLaMA-Factory/blob/main/examples/%EB%AF%B8%EB%8B%88_%ED%94%84%EB%A1%9C%EC%A0%9D%ED%8A%B8_33.ipynb",
				"https://colab.research.google.com/github/junghh21/LLaMA-Factory/blob/main/examples/%EB%AF%B8%EB%8B%88_%ED%94%84%EB%A1%9C%EC%A0%9D%ED%8A%B8_44.ipynb",
				"https://colab.research.google.com/github/junghh21/LLaMA-Factory/blob/main/examples/%EB%AF%B8%EB%8B%88_%ED%94%84%EB%A1%9C%EC%A0%9D%ED%8A%B8_55.ipynb",
				"https://colab.research.google.com/github/junghh21/LLaMA-Factory/blob/main/examples/%EB%AF%B8%EB%8B%88_%ED%94%84%EB%A1%9C%EC%A0%9D%ED%8A%B8_66.ipynb",
				"https://colab.research.google.com/github/junghh21/LLaMA-Factory/blob/main/examples/Untitled01.ipynb",
				"https://colab.research.google.com/github/junghh21/LLaMA-Factory/blob/main/examples/Untitled02.ipynb",
				"https://colab.research.google.com/github/junghh21/LLaMA-Factory/blob/main/examples/Untitled03.ipynb",
				"https://colab.research.google.com/github/junghh21/LLaMA-Factory/blob/main/examples/Untitled04.ipynb",
				"https://colab.research.google.com/github/junghh21/LLaMA-Factory/blob/main/examples/Untitled05.ipynb",
				"https://colab.research.google.com/github/junghh21/LLaMA-Factory/blob/main/examples/Untitled06.ipynb",
				"https://colab.research.google.com/github/junghh21/LLaMA-Factory/blob/main/examples/Untitled07.ipynb",
				"https://colab.research.google.com/github/junghh21/LLaMA-Factory/blob/main/examples/Untitled08.ipynb",
				"https://colab.research.google.com/github/junghh21/LLaMA-Factory/blob/main/examples/Untitled09.ipynb",
		]
sessions = ["junghhpic", "junghhpic2", "junghhpic3", "junghhpic4", "junghhpic5", "junghhmarkov"]
#sessions = ["junghh21"]
SESSION_WAIT_TIME = 900*3

async def play_once():
	async with async_playwright() as p:
		browser = await p.chromium.launch(headless=False, 
																		args=["--disable-blink-features=AutomationControlled"],
																		proxy={
																						"server": "http://168.107.19.251:8080",
																						"username": "security",
																						"password": "security"
																				})
		name = random.choice(sessions)
		context = await browser.new_context(storage_state=f"{name}.json")

		try:
			for i in range(3):
				page = await context.new_page()
				url = random.choice(urls)
				print(f"[{datetime.datetime.now():%H:%M:%S}]Start {name} : {url}")
				await page.goto(url)
				await asyncio.sleep(15)
				title = await page.title()				
				print(title)              # 🧠 Print the page title
				try:
					a = page.locator('a:has-text("Sign In")')
					await a.wait_for(timeout=100)  # Wait up to 5 seconds
					await a.click()
					await asyncio.sleep(10)
					title = await page.title()
				except Exception as e:
					pass					
				if title.startswith("Sign") or title.startswith("로그인"):
					await page.keyboard.press("Tab")
					await page.keyboard.press("Enter")
					await asyncio.sleep(10)
					title = await page.title()
					if title.startswith("Hi") or title.startswith("Welcome"):
						password = "wjdakfh2" if name == "junghhpic" else "!Wjdakfh2"
						await page.keyboard.type(password)
						await page.keyboard.press("Enter")
						await asyncio.sleep(10)				
				# 🖱️ Focus on the page (optional if already active)
				await page.focus("body")  # You can target a specific element if needed
				# ⌨️ Press Ctrl+F10
				await asyncio.sleep(2)
				await page.keyboard.down("Control")
				await page.keyboard.press("F10")
				await page.keyboard.up("Control")
				print("1")
				await asyncio.sleep(5)

				#span_locator = page.locator("mwc_dialog >> md-text-button").nth(1)
				#span_locator = page.locator("md-text-button:shadow(button)")
				dialog = page.locator("mwc-dialog")
				button = dialog.locator("md-text-button[dialogaction='ok']")
				await button.click()
				print("2")
				await asyncio.sleep(5)
				#await page.screenshot(path=f"fullpage{name}_{i}.png", full_page=True)

				# Load and show the image
				#display(Image(filename='fullpage.png'))  # Replace with your actual file name
				await context.storage_state(path=f"{name}.json")
				print(f"Session saved to {name}.json")
				await asyncio.sleep(5)
		except Exception as e:
			print(f"ERROR : {e}")
			traceback.print_exc()			
		await asyncio.sleep(SESSION_WAIT_TIME)
		for page in browser.contexts[0].pages:
			await page.close()
		await context.close()
		await browser.close()		

	try:
		print("Kill apps.")
		result = subprocess.run(
				["pgrep", "-f", "playwright"],
				stdout=subprocess.PIPE,
				stderr=subprocess.PIPE,
				text=True
		)
		pids = result.stdout.strip().split()
		print("Matching PIDs:", pids)
		for pid in pids:
			subprocess.run(["kill", "-9", f"{pid}"])
			
		await asyncio.sleep(2)
		result = subprocess.run(
						"ps aux | grep 'playwright' | grep -v grep | wc -l",
						shell=True,
						capture_output=True,
						text=True
		)		
		count = int(result.stdout.strip())
		print(f"Number of 'playwright' processes: {count}")
		import gc
		gc.collect()
	except Exception as e:
		print(f"play_once error: {e}")
	print("play_once Exit!!")

async def main():
	#while True:
		try:
			await asyncio.sleep(random.randint(10, 50))
			await play_once()
		except:
			pass

git_url = "https://junghh21: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@github.com/junghh21/baseplay1.git"
if __name__ == "__main__":
	script_dir = os.path.dirname(os.path.abspath(__file__))
	os.chdir(script_dir)
	print(f"Working directory set to: {os.getcwd()}")
	time.sleep(1)  # Give the server a moment to start
	
	#####################################################################
	git_url = "https://junghh21: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@github.com/junghh21/baseplay1.git"
	out = ''
	err = ''
	try:
		# git pull https://junghh21:$env:PAT_VAR@github.com/junghh21/baseplay1.git 
		# git add -A
		# git commit -m "asssd"
		# git push https://junghh21:$env:PAT_VAR@github.com/junghh21/baseplay1.git 
		result = subprocess.run(['git', 
														'pull',
														git_url], capture_output=True, text=True)
		out += result.stdout
		err += result.stderr
		result = subprocess.run(['git', 'add', '-A'], capture_output=True, text=True)
		out += result.stdout
		err += result.stderr
		result = subprocess.run(['git', 'commit', '-m', 'asssd'], capture_output=True, text=True)
		out += result.stdout
		err += result.stderr
		result = subprocess.run(['git', 'push',	git_url], capture_output=True, text=True)
		out += result.stdout
		err += result.stderr
	except Exception as e:
		err += e
	print("STDOUT:", out)
	print("STDERR:", err)

	try:
		asyncio.run(main())
	except Exception as e:
		print(f"coco Exit!! {e}")