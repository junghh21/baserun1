const https = require('https');
const fs = require('fs');
const httpProxy = require('http-proxy');

// Load SSL certificates
const options = {
  key: fs.readFileSync('key.pem'),
  cert: fs.readFileSync('cert.pem')
};

// Create a proxy server
const proxy = httpProxy.createProxyServer({
  changeOrigin: true,
  secure: true,
  headers: {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/115 Safari/537.36'
  }
});

// Create an HTTPS server
const server = https.createServer(options, (req, res) => {
  const target = 'https://google.com'; // Change to your target

  proxy.web(req, res, { target }, (err) => {
    res.writeHead(500, { 'Content-Type': 'text/plain' });
    res.end('Proxy error: ' + err.message);
  });
});

server.listen(3443, () => {
  console.log('HTTPS proxy running on https://localhost:3443');
});
